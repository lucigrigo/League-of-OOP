package main.data;

/**
 * Types of heroes.
 */
public enum CharacterType {
    ROGUE,
    WIZARD,
    KNIGHT,
    PYROMANCER
}


