package main.data;

/**
 * Types of locations.
 */
public enum LocationType {
    LAND,
    VOLCANIC,
    DESERT,
    WOODS
}
