package main.data;

/**
 * Types of movements.
 */
public enum MovementType {
    UP,
    DOWN,
    LEFT,
    RIGHT,
    NONE
}
