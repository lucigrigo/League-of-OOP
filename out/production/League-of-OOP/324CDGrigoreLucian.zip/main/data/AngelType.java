package main.data;

public enum AngelType {
    DamageAngel,
    DarkAngel,
    Dracula,
    XPAngel,
    GoodBoy,
    LevelUpAngel,
    LifeGiver,
    SmallAngel,
    Spawner,
    TheDoomer
}
