package main.data;

import main.angels.Angel;

public interface Visitable {

    void getHelpedBy(Angel angel);
}
