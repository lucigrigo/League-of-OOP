package main.data;

/**
 * Types of heroes.
 */
public enum HeroType {
    ROGUE,
    WIZARD,
    KNIGHT,
    PYROMANCER
}


